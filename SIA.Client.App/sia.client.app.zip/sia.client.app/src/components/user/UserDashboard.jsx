
export default function UserDashboard() {
    return (
        <div>
            User Dashboard
        </div>
    )
}