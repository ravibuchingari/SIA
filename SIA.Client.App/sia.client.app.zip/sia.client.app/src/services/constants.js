export const CONTROLLER_HOME = 'home';
export const CONTROLLER_ADMIN_HOME = 'admin/home';
export const CONTROLLER_USER_HOME = 'user/home';
export const USER_ROLES = {
  ADMIN: 'Admin',
  VIEWER: 'User',
};